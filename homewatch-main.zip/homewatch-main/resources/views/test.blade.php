

@foreach($name_producer as $film)
    <br> producer {{ $film }}

@endforeach()


<br>

<br>

<br>
@foreach($genre as $film)
    <br> producer {{ $film }}

@endforeach()


<br>

<br>

<br>
@foreach($actor as $film)
    <br> producer {{ $film }}

@endforeach()